<!DOCTYPE html>
<html>
<head>
<meta charset="utf_8">
<title>customer_product</title><!--网站名字-->
</head>
<body><!--body内是可见内容-->
<b>product_type</b><!--h1之间为标题-->
<table border="1">
<tr>
    <td><a href="cat_litter.php" >cat litter</a></td>
</tr>
<tr>
    <td><a href="health_care.php" >health care</a></td>
</tr>
<tr>
    <td><a href="toy.php" >toy</a></td>
</tr>
<tr>
    <td><a href="pet_food.php" >pet food</a></td>
</tr>
<tr>
    <td><a href="necessities.php" >daily necessities</a></td>
</tr>
<hr>
</table>


</table>
</body>

<footer>
<style>
    footer{
 width: 100%;
    height:100px;   /* footer的高度一定要是固定值*/ 
    position:absolute;
    bottom:0px;
    left:0px;
    background: #3333;
}
</style>

<table border="2" class="nev">
      
        <p align='center'>
        <a href="firstpage.html" >home page</a>
    </p>

      
  </table>

</footer>
</html>
<?php
header ('Content-type:text/html;charset=utf-8');

//数据库相关信息

$servername = "localhost";
$username = "root";
$password = "";
$mysql_database = "project1"; 
// 创建连接
$conn = new mysqli($servername, $username, $password,$mysql_database);
// 检测连接
if ($conn->connect_error) {
    die("Failed to connect: " . $conn->connect_error);
}



 //如果表单中不为空
 $user = $_POST['userid'];
 $pass = $_POST['password'];
 $sql="SELECT * FROM customer where person_id='{$user}' and password='{$pass}'"; 

 $result=$conn->query($sql);
 $row = mysqli_num_rows($result);
 //若表中存在输入的用户名和密码，row=1；若表中用户名不存在或密码错误，则row=0

 if($row == 1){
     echo "Successful!";
 }
 else{
     header("location: ./customerlogin.php");exit;
 }	
?>