<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>health_care</title>
   
</head>

<body>
<form action="./health_care.php" method="post">

    <br>
    <!-- 购买部分 -->
    <div class="center">
        <!-- 购买框 -->
        <div class="user">
            <p class="cuser">Create My Order</p>
            <!-- order -->
            <div class="form">
                <div class="user1">
                    <input type="text" placeholder="Product_ID" name="productid">
                </div>
                <div class="user2">
                    <input type="text" placeholder="Store_ID"  name="storeid">
                </div>
                <div class="user2">
                    <input type="text" placeholder="Person_ID" name="personid">
                </div>
                <div class="user2">
                    <input type="text" placeholder="Password" name="password3">
                </div>
                <div class="user2">   
                    <input type="int" placeholder="Purchase Number: limit 3" name="num">
                </div> 
                <br>
                <div>
                <input type="submit" value="submit" name="login" class="button" />
                </div>
            </div>
            <div style="height: 25px;"></div>
            <div class="mima">
                       
        </div>
    </div>
     <tr></tr>

  <h1 align="center"> Product List</h1>
  <form action ="order.php" method = "post" name= "indexf">
    <p align="center"><input type = "text" value = "" name = "search" /><input type = "submit" value = "Search" name = "submit" /></p>
    <table align="center" border="1px" cellspacing = "0px" width = "800px">
    <tr><th>Product ID</th><th>Store ID</th><th>Name</th><th>Price</th><th>Efficacy</th><th>Expiration_date</th></tr>
<?php

$servername = "localhost";
$user = "root";
$password = "";
$mysql_database = "project1"; 


$link =  new mysqli($servername,$user,$password,$mysql_database);

if (!$link){
   exit('数据库连接失败！');
}






if(empty($_REQUEST["search"])){
  
  $res = mysqli_query($link,"select product_id, store_id, name, price, efficacy,expiration_date from inventory JOIN health_care USING (product_id) LIMIT 50");
}else{
  
  $sel = $_REQUEST["search"];//接收搜索框中的内容
  $res = mysqli_query($link, "select product_id, store_id, name, price, efficacy,expiration_date from inventory JOIN health_care USING (product_id) WHERE product_id = '$sel' LIMIT 50");
}

while($row=mysqli_fetch_array($res)){
  echo'<tr>';
  echo"<td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td><td>$row[5]</td>";
  echo'</tr>';
}
echo(microtime());
?>
    </table>
  </form>
</body>




</html>

<?php
if(isset($_POST['login'])){
$servername = "localhost";
$username = "root";
$password = "";
$mysql_database = "project1"; 
// 创建连接
$conn = new mysqli($servername, $username, $password,$mysql_database);
// 检测连接
if ($conn->connect_error) {
    die("Failed to connect: " . $conn->connect_error);
}

$order_number = date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 4);

$productid = "";
if (isset($_POST["productid"])){
$productid= trim($_POST["productid"]);
}

$storeid = "";
if (isset($_POST["storeid"])){
$storeid= $_POST["storeid"];
}

$personid = "";
if (isset($_POST["personid"])){
$personid= $_POST["personid"];
}

$buynum = "";
if (isset($_POST["num"])){
$buynum = $_POST["num"];
}

$passwrd = "";
if (isset($_POST["password3"])){
$passwrd= trim($_POST["password3"]);
}


$chaxun="SELECT store_id FROM store where store_id='{$storeid}'"; 
$chaxun1="SELECT product_id FROM health_care where product_id='{$productid}'";
$chaxun2="SELECT person_id  FROM customer where person_id='{$personid}'AND password='{$passwrd}' "; # 
$sql_updata = "SELECT * from inventory WHERE product_id = '{$productid}'AND store_id='{$storeid}' " ;
$sql1_update="UPDATE inventory SET inventory_num=inventory_num-1 where product_id = '{$productid}'AND store_id='{$storeid}'";
$sql = "INSERT into order_list(order_id,person_id) values('$order_number','$personid')";
$sql1 = "INSERT into consist(order_id,product_id) values('$order_number','$productid')";


$chaxunresult=$conn->query($chaxun);
$chaxunrow = mysqli_num_rows($chaxunresult);
$chaxunresult1=$conn->query($chaxun1);
$chaxunrow1 = mysqli_num_rows($chaxunresult1);
$chaxunresult2=$conn->query($chaxun2);
$chaxunrow2 = mysqli_num_rows($chaxunresult2);
$result_updata = $conn->query($sql_updata);
$row_updata = mysqli_num_rows($result_updata);
 //若表中存在输入的用户名和密码，row=1；若表中用户名不存在或密码错误，则row=0
if($chaxunrow == 1 and $chaxunrow1==1 and $chaxunrow2==1 and $row_updata == 1 and($buynum==1 or $buynum==2 or $buynum==3)){
     echo "Successful!";
     $result1_updata=$conn->query($sql1_update);
     $order_insert=$conn->query($sql);
     $consist_insert=$conn->query($sql1);
 }
else {
    echo"Please recheck your information";
    header("location: ./health_care.php");#exit;
}



echo(microtime());
mysqli_close($conn);//关闭数据库连接
}
?>