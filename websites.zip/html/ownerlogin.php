<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
      background: url('https://pic2.zhimg.com/v2-b6399145c80f909e020874d3c670ae44_r.jpg?source=1940ef5c') no-repeat;
      background-size: 100% 130%;
    }

    #login_box {
      width: 20%;
      height: 400px;
      background-color: #00000060;
      margin: auto;
      margin-top: 10%;
      text-align: center;
      border-radius: 10px;
      padding: 50px 50px;
    }

    h2 {
      color: #ffffff90;
      margin-top: 5%;
    }

    #input-box {
      margin-top: 5%;
    }

    span {
      color: #fff;
    }

    input {
      border: 0;
      width: 60%;
      font-size: 15px;
      color: #fff;
      background: transparent;
      border-bottom: 2px solid #fff;
      padding: 5px 10px;
      outline: none;
      margin-top: 10px;
    }

    button {
      margin-top: 50px;
      width: 60%;
      height: 30px;
      border-radius: 10px;
      border: 0;
      color: #fff;
      text-align: center;
      line-height: 30px;
      font-size: 15px;
      background-image: linear-gradient(to right, #30cfd0, #330867);
    }

    #sign_up {
      margin-top: 45%;
      margin-left: 60%;
    }

    a {
      color: #b94648;
    }
  </style>
</head>

<body>
<form action="./ownerlogin.php" method="post">
  <div id="login_box">
    <h2>Login as a store owner</h2>
    <div id="input_box">
      <input type="text" placeholder="enter id" name="ownerid">
    </div>
    <div class="input_box">
      <input type="text" placeholder="enter the password" name="password3">
    </div>
     <input type="submit" value="login" name="login"/>
  </div>
</form>
</body>
</html>

<?php
if(isset($_POST['login'])){
header ('Content-type:text/php;charset=utf-8');

//数据库相关信息

$servername = "localhost";
$username = "root";
$password = "";
$mysql_database = "project1"; 
// 创建连接
$conn = new mysqli($servername, $username, $password,$mysql_database);
// 检测连接
if ($conn->connect_error) {
    die("Failed to connect: " . $conn->connect_error);
}



 //如果表单中不为空
 $user = $_POST['ownerid'];
 $pass = $_POST['password3'];
 $sql="SELECT * FROM owner where person_id='{$user}' and password='{$pass}'"; 

 $result=$conn->query($sql);
 $row = mysqli_num_rows($result);

 if($row == 1){
     echo "Successful!";
     if($user=="o104057"){
      header("location: ./store.php");
     }
     else{
     header("location: ./store_owner.php");
     }
 }
 else{
     header("location: ./ownerlogin.php");
 }	


}
session_start();
$_SESSION['user']= "";
if (isset($_POST["ownerid"])){
$_SESSION['user']= $_POST["ownerid"];
}
echo $_SESSION['user'];
echo(microtime());
?>