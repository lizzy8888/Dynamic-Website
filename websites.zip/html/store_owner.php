<!doctype html>
<html>
<head>
  <meta charset = "utf-8">
  <title>order.php</title>
</head>

<body>
  <style type="text/css">
  .container{
      width:0.2px;
      height:0.2px;
      text-align:right;
    }
  </style>

  <div class="container">
    <img src="logo.jpg" />
    <div class='img'></div>
    </div>

  <h1 align="center"> Store List</h1>
  <form action ="" method = "post" name= "indexf">
      <p align="center"><input type = "text" name = "sel" /><input type = "submit" value = "Search" name = "selsub" /></p>
      <table align="center" border="1px" cellspacing = "0px" width = "800px">
      <tr><th>Store ID</th><th>Owner ID</th></tr>


<?php



$servername = "localhost";
$username = "root";
$password = "";
$mysql_database = "project1"; 
// 创建连接
$conn = new mysqli($servername, $username, $password,$mysql_database);
// 检测连接
if ($conn->connect_error) {
    die("Failed to connect: " . $conn->connect_error);
}

session_start();
$user=$_SESSION['user'];
#echo $_SESSION['user'];
#echo $user;

if(empty($_POST["selsub"])){

  $res = mysqli_query($conn,"select store_id, owner_id from store where owner_id='{$user}'");
}
else{
  $sel = $_POST ["sel"];
  $res = mysqli_query($conn, "select store_id,owner_id from store where owner_id='{$user}' and store_id='$sel'");
}

while($row=mysqli_fetch_array($res)){
  echo'<tr>';
  echo"<td>$row[0]</td><td>$row[1]</td>";
  echo'</tr>';
}
echo(microtime());
?>
    </table>
  </form>
</body>



<?php
mysqli_close($conn);//关闭数据库连接
?>


<footer>
<style>
    footer{
 width: 100%;
    height:100px;   /* footer的高度一定要是固定值*/ 
    position:absolute;
    bottom:0px;
    left:0px;
    background: #3333;
}
</style>

<table border="2" class="nev">
      
        <p align='center'>
        <a href="firstpage.html" >home page</a>
    </p>

      
  </table>

</footer>

</html>