

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
      background: url('https://pic1.zhimg.com/v2-149c726ff219b8c678783b0ca5cae6e6_r.jpg?source=1940ef5c') no-repeat;
      background-size: 100% 300%;
    }

    #login_box {
      width: 20%;
      height: 400px;
      background-color: #00000060;
      margin: auto;
      margin-top: 10%;
      text-align: center;
      border-radius: 10px;
      padding: 50px 50px;
    }

    h2 {
      color: #ffffff90;
      margin-top: 5%;
    }

    #input-box {
      margin-top: 5%;
    }

    span {
      color: #fff;
    }

    input {
      border: 0;
      width: 60%;
      font-size: 15px;
      color: #fff;
      background: transparent;
      border-bottom: 2px solid #fff;
      padding: 5px 10px;
      outline: none;
      margin-top: 10px;
    }

    button {
      margin-top: 50px;
      width: 60%;
      height: 30px;
      border-radius: 10px;
      border: 0;
      color: #fff;
      text-align: center;
      line-height: 30px;
      font-size: 15px;
      background-image: linear-gradient(to right, #30cfd0, #330867);
    }

    #sign_up {
      margin-top: 45%;
      margin-left: 60%;
    }

    a {
      color: #b94648;
    }
  </style>
</head>

<body>
<style type="text/css">
  .container{
      width:0.2px;
      height:0.2px;
      text-align:right;
    }
  </style>

  <div class="container">
    <img src="logo.jpg" />
    <div class='img'></div>
    </div>

<hr>
<p align="center" style="font-size:40px">Please choose the store you want to manege:</p>
<hr>



<table border="2" class="nev">
      <tr>
        <th ><a href="store_1001.php" >store s_t100000</a></th>
        <th ><a href="store_1002.php" >store s_t100001</a></th>
        <th ><a href="store_1003.php" >store s_t100002</a></th>

</a></th>

      </tr>
  </table><hr/>

<style>
table {margin: auto;} body{text-align: center;}
p{font-family:italic bold "微软雅黑";}	
</style>



</body>
<footer>
<style>
    footer{
 width: 100%;
    height:100px;   /* footer的高度一定要是固定值*/ 
    position:absolute;
    bottom:0px;
    left:0px;
    background: #3333;
}
</style>

<table border="2" class="nev">
      
        <p align='center'>
        <a href="firstpage.html" >home page</a>
    </p>

      
  </table>

</footer>
</html>

