<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
      background: url('https://ts1.cn.mm.bing.net/th/id/R-C.ecff1cfb92116d589bace7bfbe4a027d?rik=vRgPklYg2woMvA&riu=http%3a%2f%2fimage.qianye88.com%2fpic%2fe8d831b858bd0b0f4ae12a68dbe6bfc9&ehk=TAuqVPpDUR9JpEGlJCv8OjdyssIcylTcdb39XdQvmG8%3d&risl=&pid=ImgRaw&r=0') no-repeat;
      background-size: 100% 130%;
    }

    #login_box {
      width: 20%;
      height: 400px;
      background-color: #00000060;
      margin: auto;
      margin-top: 10%;
      text-align: center;
      border-radius: 10px;
      padding: 50px 50px;
    }

    h2 {
      color: #ffffff90;
      margin-top: 5%;
    }

    #input-box {
      margin-top: 5%;
    }

    span {
      color: #fff;
    }

    input {
      border: 0;
      width: 60%;
      font-size: 15px;
      color: #fff;
      background: transparent;
      border-bottom: 2px solid #fff;
      padding: 5px 10px;
      outline: none;
      margin-top: 10px;
    }

    button {
      margin-top: 50px;
      width: 60%;
      height: 30px;
      border-radius: 10px;
      border: 0;
      color: #fff;
      text-align: center;
      line-height: 30px;
      font-size: 15px;
      background-image: linear-gradient(to right, #30cfd0, #330867);
    }

    #sign_up {
      margin-top: 45%;
      margin-left: 60%;
    }

    a {
      color: #b94648;
    }
  </style>
</head>

<body>
<style type="text/css">
  .container{
      width:0.2px;
      height:0.2px;
      text-align:right;
    }
  </style>

  <div class="container">
    <img src="logo.jpg" />
    <div class='img'></div>
    </div>
<form action="./managerlogin.php" method="post">
  <div id="login_box">
    <h2>Login as a manager</h2>
    <div id="input_box">
      <input type="text" placeholder="enter id" name="managerid">
    </div>
    <div class="input_box">
      <input type="text" placeholder="enter the password" name="password">
    </div>
    <input type="submit" value="login" name="login"/>
  </div>
</form>
</body>

<footer>
<style>
    footer{
 width: 100%;
    height:100px;   /* footer的高度一定要是固定值*/ 
    position:absolute;
    bottom:0px;
    left:0px;
    background: #3333;
}
</style>

<table border="2" class="nev">
      
        <p align='center'>
        <a href="firstpage.html" >home page</a>
    </p>

      
  </table>
</footer>
</html>

<?php

 //如果表单中不为空
 if(isset($_POST['login'])){
 $servername = "localhost";
 $user = "root";
 $password = "";
 $mysql_database = "project1"; 
 
 
 #$link = mysqli_connect($servername,$use,$password,$mysql_database);
 $link =  new mysqli($servername,$user,$password,$mysql_database);
 

 $user = $_POST['managerid'];
 $pass = $_POST['password'];
 $sql="SELECT * FROM manager where person_id='{$user}' and password='{$pass}'"; 

 $result=$link->query($sql);
 $row = mysqli_num_rows($result);
 //若表中存在输入的用户名和密码，row=1；若表中用户名不存在或密码错误，则row=0

 if($row == 1){
     echo "Successful!";
     header("location: ./order.php");
 }
 else{
     header("location: ./managerlogin.php");
 }	
}
?>