
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>s_t100000</title>
  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&amp;display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
</head>

<body>
  <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Store_ID: s_t110000</h1>
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
  <form action ="" method = "post" name= "indexf">
      <table align="center" border="1px" cellspacing = "0px" width = "800px">
      <tr><th>Product ID</th><th>Store ID</th><th>Inventory num</th></tr>

<?php

$servername = "localhost";
$user = "root";
$password = "";
$mysql_database = "project1"; 


$link =  new mysqli($servername,$user,$password,$mysql_database);


if (!$link){
   exit('数据库连接失败！');
}

$res = mysqli_query($link,"select product_id, store_id, inventory_num from inventory where store_id='s_t110000' LIMIT 10");


while($row=mysqli_fetch_array($res)){
  echo'<tr>';
  echo"<td>$row[0]</td><td>$row[1]</td><td>$row[2]</td>";
  echo'</tr>';
}

?>
    </table>
<br>


<form action="./store_1001.php" method="post">
  <div id="increase_inventory_num">
    <h2>Replenish your inventory</h2>
    <div id="input_box">
       <h4>Notice: please fill in all the boxes!</h4>
      <input type="text" placeholder="Product_ID" name="product_id">
    </div>
    <div class="input_box">
      <input type="text" placeholder="Store_ID" name="store_id">
    </div>
    <div class="input_box">
      <input type="num" placeholder="inventory_num" name="inventory_num">
    </div>
    <div class="input_box">
      <input type="text" placeholder="your owner password" name="password">
    </div>
    </div>
    <input type="submit" value="Replenish" name="replenish" class="button" />
  
  </div>
  </form>



</body>
<footer>
<style>
    footer{
 width: 100%;
    height:100px;   /* footer的高度一定要是固定值*/ 
    position:absolute;
    bottom:0px;
    left:0px;
    background: #3333;
}
</style>

<table border="2" class="nev">
      
        <p align='center'>
        <a href="firstpage.html" >home page</a>
    </p>

      
  </table>

</footer>
</html>

<?php
if(isset($_POST['replenish'])){
$product_id = "";
if (isset($_POST["product_id"])){
$product_id= trim($_POST["product_id"]);
}
$store_id = "";
if (isset($_POST["store_id"])){
$store_id= trim($_POST["store_id"]);
}
//根据store找到对应的owner id，再去找对应的密码
    
$inventory_num = "";
if (isset($_POST["inventory_num"])){
$inventory_num= trim($_POST["inventory_num"]);
}

$password2 = "";
if (isset($_POST["password"])){
$password2= trim($_POST["password"]);
}

$sql = "SELECT * from inventory WHERE product_id = '{$product_id}'AND store_id='{$store_id}' " ;
            
$sql1="UPDATE inventory SET inventory_num=inventory_num+'{$inventory_num}' where product_id = '{$product_id}'AND store_id='{$store_id}'";

$sql2="SELECT owner_id from store WHERE store_id = '{$store_id}' ";
            
$res =$link->query($sql2);
$row1=mysqli_fetch_array($res);
$sql3="SELECT password from owner WHERE person_id = '{$row1[0]}'";

$res1 = $link->query($sql3);
$row2=mysqli_fetch_array($res1);

$result = $link->query($sql);
$row = mysqli_num_rows($result);
if($row == 1 and $password2==$row2[0]){
      echo "Successful!";
      $result1 = $link->query($sql1);
    }
else{
      echo "Wrong Input!";
}  
}
echo(microtime());
?>
<?php
    mysqli_close($link);//关闭数据库连接
?>