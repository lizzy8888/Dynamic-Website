<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    body {
      background: url('https://pic1.zhimg.com/v2-149c726ff219b8c678783b0ca5cae6e6_r.jpg?source=1940ef5c') no-repeat;
      background-size: 100% 130%;
    }

    #login_box {
      width: 20%;
      height: 400px;
      background-color: #00000060;
      margin: auto;
      margin-top: 10%;
      text-align: center;
      border-radius: 10px;
      padding: 50px 50px;
    }

    h2 {
      color: #ffffff90;
      margin-top: 5%;
    }

    #input-box {
      margin-top: 5%;
    }

    span {
      color: #fff;
    }

    input {
      border: 0;
      width: 60%;
      font-size: 15px;
      color: #fff;
      background: transparent;
      border-bottom: 2px solid #fff;
      padding: 5px 10px;
      outline: none;
      margin-top: 10px;
    }

    button {
      margin-top: 50px;
      width: 60%;
      height: 40px;
      border-radius: 10px;
      border: 0;
      color: #fff;
      text-align: center;
      line-height: 20px;
      font-size: 20px;
      background-image: linear-gradient(to right, #30cfd0, #330867);
    }

    #sign_up {
      margin-top: 45%;
      margin-left: 60%;
    }

    a {
      color: #b94648;
    }
  </style>
</head>

<body>
<form action="./customercreate.php" method="post">
  <div id="login_box">
    <h2>Create your own shopping account</h2>
    <div id="input_box">
       <h4>Notice: your id must start with 'c'!</h4>
      <input type="text" placeholder="enter id" name="userid">
    </div>
    <div class="input_box">
      <input type="text" placeholder="enter the name" name="name">
    </div>
    <div class="input_box">
      <input type="password" placeholder="enter the password" name="password">
    </div>
    <div class="input_box">
      <input type="address" placeholder="enter the address" name="address">
    </div>
    <div class="input_box">
      <input type="int" placeholder="enter the credit card" name="credit">
    </div>
    <input type="submit" value="submit" name="login" class="button" />
  
  </div>
  </from>
</body>


</html>

<?php
if(isset($_POST['login'])){
$userid = trim($_POST['userid']);
$customername = trim($_POST['name']);
$password = trim($_POST['password']);
$useraddress = trim($_POST['address']);
$usercredit = trim($_POST['credit']);
if($userid[0]="c"){
$servername = "localhost";
$username = "root";
$password = "";
$mysql_database = "project1"; 
// 创建连接
$conn = new mysqli($servername, $username, $password,$mysql_database);
// 检测连接
if ($conn->connect_error) {
    die("Failed to connect: " . $conn->connect_error);
}


$sql = "insert into customer(person_id,name,password,address,credit_card_id) values('$userid','$customername', '$password' ,'$useraddress','$usercredit' )";

$result = mysqli_query($conn, $sql);

if ($result) {
  header("location: ./firstpage.html");
} else {
    echo 'Fail to create';
}
echo(microtime());
mysqli_close($conn);//关闭数据库连接
}
else{
  echo "Please input the right customer id!";
  header("location: ./customercreate.php");
}
}
?>
